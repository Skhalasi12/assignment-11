import Foundation
class Classstud{
    var Spid = 0
    var Name = ""
    var Password = ""
    var Class = ""
    var Phoneno = ""
    
    init(Spid:Int, Name: String, Password :String, Class:String, Phoneno : String ) {
        self.Spid = Spid
        self.Name = Name
        self.Password = Password
        self.Class = Class
        self.Phoneno = Phoneno
    }
    
}
