
import Foundation
class Noticeclass{
    var id = 0
    var title = ""
    var notice = ""
    var date = ""
    
    init(id:Int, title: String, notice :String, date:String ) {
        self.id = id
        self.title = title
        self.notice = notice
        self.date = date
    }    
}



